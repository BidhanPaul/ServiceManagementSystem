package edu.frau.service.Service.Management.dto;

import java.time.LocalDate;

public class OrderSubstitutionRequest {
    public String newSpecialistName;
    public LocalDate substitutionDate;
    public String comment;
}
