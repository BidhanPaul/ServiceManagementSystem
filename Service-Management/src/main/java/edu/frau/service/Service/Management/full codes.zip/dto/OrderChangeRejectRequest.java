package edu.frau.service.Service.Management.dto;

public class OrderChangeRejectRequest {
    public String reason;
}
