package edu.frau.service.Service.Management.model;

public enum RequestType {
    SINGLE,
    MULTI,
    TEAM,
    WORK_CONTRACT   // <-- add this if it’s missing
}
