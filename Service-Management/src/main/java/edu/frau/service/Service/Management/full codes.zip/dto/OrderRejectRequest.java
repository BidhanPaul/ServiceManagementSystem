package edu.frau.service.Service.Management.dto;

public class OrderRejectRequest {
    public String reason;
}