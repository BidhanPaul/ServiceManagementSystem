package edu.frau.service.Service.Management.repository;

import edu.frau.service.Service.Management.model.Contract;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ContractRepository extends JpaRepository<Contract, Long> {

    // ✅ Needed by RequestServiceImpl (Group-2 rule)
}
