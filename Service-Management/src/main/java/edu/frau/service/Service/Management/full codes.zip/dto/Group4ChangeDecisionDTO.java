package edu.frau.service.Service.Management.dto;

public class Group4ChangeDecisionDTO {
    public String decision; // "ACCEPTED" | "REJECTED"
    public String reason;   // optional if rejected
}
