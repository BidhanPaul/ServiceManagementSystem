package edu.frau.service.Service.Management.model;

public enum NotificationCategory {
    SYSTEM,
    DIRECT_MESSAGE
}
