package edu.frau.service.Service.Management.dto;

public class OrderFeedbackRequest {
    public int rating;     // 1..5
    public String comment; // optional
}