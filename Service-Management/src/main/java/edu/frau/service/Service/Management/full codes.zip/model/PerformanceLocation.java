package edu.frau.service.Service.Management.model;

public enum PerformanceLocation {
    ONSHORE, //Onsite
    NEARSHORE, //
    OFFSHORE
}
