package edu.frau.service.Service.Management.dto;

public class DirectMessageRequest {
    public String threadKey;
    public String requestId;

    public String senderUsername;
    public String senderRole;

    public String recipientUsername;
    public String recipientRole;

    public String message;
}
