package edu.frau.service.Service.Management.model;

public enum OrderChangeStatus {
    NONE,
    PENDING,
    APPROVED,
    REJECTED
}
